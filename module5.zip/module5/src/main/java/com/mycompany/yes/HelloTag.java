/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.yes;

//import javax.servlet.jsp.JspWriter;
//import javax.servlet.jsp.JspException;
//import javax.servlet.jsp.tagext.JspFragment;
//import javax.servlet.jsp.tagext.SimpleTagSupport;
//import java.io.*;
//import javax.servlet.jsp.tagext.*;
//import javax.servlet.jsp.*;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
 
public class HelloTag extends SimpleTagSupport {

    /**
     * Called by the container to invoke this tag.The implementation of this
 method is provided by the tag library developer, and handles all tag
 processing, body iteration, etc.
     * @throws javax.servlet.jsp.JspException
     * @throws java.io.IOException
     */
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author cnsub
 */

    private String table;
    private String username;
    private String health;
    private String nin;
    private String locat;
    private String email;
    private String role;
    private String pass;

    /**
     * Called by the container to invoke this tag.The implementation of this
 method is provided by the tag library developer, and handles all tag
 processing, body iteration, etc.
     * @throws javax.servlet.jsp.JspException
     */
    @Override
    public void doTag() throws JspException {
        JspWriter out = getJspContext().getOut();
        
        try {
           // String[] arr = values.split(",");
            try{
                Class.forName("com.mysql.jdbc.Driver");
                try{
                if(username!=null){
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/goat","root","");
                    Statement st = con.createStatement();
                    //if(arr.length>1){
                    out.println(nin);
                    //st.execute("insert into "+table+"(title,date,time,place)values('"+arr[0]+"','"+arr[1]+"','"+arr[2]+"','"+arr[3
                    st.execute("insert into "+table+"(name, healthcenter, nin, role, email, location,password)values('"+username+"','"+health+"','"+nin+"','"+role+"','"+email+"','"+locat+"','"+pass+"')");
                   // }
                }
                }catch (SQLException ex){
                out.println("Error"+ ex.getMessage());
                }
            
            }catch (ClassNotFoundException ex){
              out.println("Error"+ex.getMessage());
            }
            JspFragment f = getJspBody();
            if (f != null) {
                f.invoke(out);
            }

            // TODO: insert code to write html after writing the body content.
            // e.g.:
            //
            // out.println("    </blockquote>");
        } catch (java.io.IOException ex) {
            throw new JspException("Error in BookingTagHandler tag", ex);
        }
    }

    public void setTable(String table) {
        this.table = table;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    public void setHealth(String health) {
        this.health = health;
    }

    public void setRole(String role) {
        this.role = role;
        
    }
    
    public void setNin(String nin) {
        this.nin = nin;
    }
    
    public void setLocat(String locat) {
        this.locat = locat;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public void setPass(String pass) {
        this.pass = pass;
    }
    
    
    
    
}
